# read argument and save to variable INPUT
INPUT=$1

# Determine if input is equal to Dog or Cat
# If the input is Dog, print message to specify so
# otherwise, print that INPUT is equal to Cat.
# If the input is not Dog or Cat, print a message
# specifying so.

if [ $INPUT == Dog ] || [ $INPUT == Cat ]
then
	if [ $INPUT == Dog ]
	then
		echo "$INPUT is equal to Dog or Cat. In fact, it is equal to Dog!"
	else
		echo "$INPUT is equal to Dog or Cat. In fact, it is equal to Cat!"
	fi
else
	echo "$INPUT is not equal to Dog or Cat"
fi
