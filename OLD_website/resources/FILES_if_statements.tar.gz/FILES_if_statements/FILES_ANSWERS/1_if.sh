# read in argument and save it to variable INPUT
INPUT=$1

# Determine if input is greater than 10
if [ $INPUT -gt 10 ]
then
	echo "$INPUT is greater than 10"
else
	echo "$INPUT is less than or equal to 10"
fi
