# read in arguments as INPUT1 and INPUT2
INPUT1=$1
INPUT2=$2

# determines if INPUT1 and INPUT2 are equal to one another
if [ $INPUT1 == $INPUT2 ]
then
	echo "$INPUT1 is equal to $INPUT2"
else
	echo "$INPUT1 is not equal to $INPUT2"
fi

