# read in variable as argument
INPUT=$1

# open INPUT file and loop through each line with the while loop
# then determine if the number is greater than or equal to 5
# then determine is the remainder of the number is equal to 0 when divided by 2
# and print results
# if the number is less than 5 determine if the number is odd or even using
# the value of the remainder when divided by 0 and print results
cat $INPUT | \
while read number
do
	if [ $number -ge 5 ] 
	then
		if [ $(($number%2)) -eq 0 ]
		then
			echo -e "$number\tgreater than 5\teven"
		else
			echo -e "$number\tgreater than 5\todd"
		fi
	else
		if [ $(($number%2)) == 0 ] 
                then
                        echo -e "$number\tless than 5\teven" 
                else
                        echo -e	"$number\tless than 5\todd"
		fi
	fi
done
