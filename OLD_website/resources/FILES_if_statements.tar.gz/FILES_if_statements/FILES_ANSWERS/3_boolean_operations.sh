# read in argument and save it to variable INPUT
INPUT=$1

# determine if input is greater than or equal to 100 and less than 1000
if [ $INPUT -ge 100 ] && [ $INPUT -lt 1000 ]
then
	echo "$INPUT is greater than or equal to 100 and less than 1000"
else
	echo "$INPUT is not greater than or equal to 100 and less than 1000"
fi
